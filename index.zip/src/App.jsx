import React from 'react';
 import Login from './pages/Login';
 import Forgotpass from './pages/Forgotpass';
 import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Homestore from './pages/Homestore';
import Addcart from './pages/Addcart';

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Login/>} />
        <Route path="/forgotpassword" element={<Forgotpass/>} />
        <Route path = "/homestore" element={<Homestore/>}/>
        <Route path='/addcart' element={<Addcart/>}/>
        
      </Routes>
    </Router>
  );
};

export default App;
