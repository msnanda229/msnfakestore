import React from 'react';

const Forgotpass = () => {
  return (
    <div>
      <center>
        <h1>I will mail you 🔐</h1>
        <br /><br />
      </center>
    </div>
  );
};

export default Forgotpass;
