import React from 'react';
import { useLocation } from 'react-router-dom';

const Addcart = () => {
  const loc = useLocation();
  const products = loc.state;
  return (
    <div>
      <p>{products.title}</p>
      <img src={products.image} alt="No Image" width={300}/>

    </div>
  );
}

export default Addcart;
