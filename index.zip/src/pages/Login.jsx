import React, { useState } from 'react';
import { ToastContainer, toast } from 'react-toastify';
import { Link, useNavigate } from 'react-router-dom'; // ✅ only useNavigate is needed
import 'react-toastify/dist/ReactToastify.css';

const Login = () => {
  const [name, setname] = useState('');
  const [email, setemail] = useState('');
  const [password, setpassword] = useState('');

  const navigate = useNavigate(); // ✅ Correct usage

  const autor = (e) => {
    e.preventDefault();
    console.log(name, email, password);

    if (name === '' || email === '' || password === '') {
      toast.error("Enter valid data");
    } else {
      toast.success("LogIn Successfully");
      setTimeout(() => {
        navigate('/homestore'); // ✅ Redirect after toast
      }, 2000);
    }
  };

  return (
    <div>
      <form>
        <center>
          <h1>Style begins at login — dress up, log in, stand out</h1>
          <br /><br />
          Name: <input type="text" value={name} onChange={(e) => setname(e.target.value)} placeholder="Enter your name" />
          <br /><br />
          Email: <input type="email" value={email} onChange={(e) => setemail(e.target.value)} placeholder="Enter your Email" />
          <br /><br />
          Password: <input type="password" value={password} onChange={(e) => setpassword(e.target.value)} placeholder="Enter your password" />
          <br /><br />
          <Link to="/forgotpassword">Forgot Password?</Link>
          <br /><br />
          <button onClick={autor}>Log in</button>
        </center>
      </form>

      <ToastContainer position="top-center" autoClose={2000} theme="colored" />
    </div>
  );
};

export default Login;
