import React, { useEffect, useState } from 'react';
import './Homestore.css';
import { Link, useNavigate } from 'react-router-dom';

const Homestore = () => {
  const [products, setproducts] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    fetch("https://fakestoreapi.com/products")
      .then(response => response.json())
      .then((data) => setproducts(data))
      .catch((err) => console.error(err));
  }, []);
  const gotocart = (item)=>{
    navigate('/addcart',{state:item})
}
  return (

    <div className="store-container">
            <h1 className="store-title">🛒 MSN FAKE STORE</h1>

     <nav className="navbar">
  <Link to="/homestore" className="nav-link">Home</Link>
  <Link to="/addcart" className="nav-link" onClick={()=>navigate('/addcart')}>Cart</Link>
  <Link to="/buy" className="nav-link">Buy</Link>
  </nav>

  <br></br> <br></br>
      <div className="product-grid">
        {products.map((item, index) => (
          <div key={index} className="product-card">
            <img src={item.image} alt={item.title} className="product-image" />
            <h3 className="product-title">{item.title}</h3>
            <p className="product-price">${item.price}</p>
            <p className="product-desc">{item.description.slice(0,100)}</p>
            <button onClick={()=>gotocart(item)}>Add to cart</button>
            <button>Buy</button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Homestore;
